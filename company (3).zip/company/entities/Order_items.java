package com.company.entities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Order_items {

    private int order_id;
    private int order_item_id;
    private String product_id ;
    private String seller_id ;
    private String shipping_limit_date;
    private int product_price ;
    private int product_cost ;
    private int freight_value;




    public Order_items(){

    }

    public Order_items(int order_item_id,String product_id,String seller_id,String shipping_limit_date,int product_price,int product_cost,int freight_value){
        setOrder_item_id(order_item_id);
        setProduct_id(product_id);
        setSeller_id(seller_id);
        setShipping_limit_date(shipping_limit_date);
        setProduct_price(product_price);
        setProduct_cost(product_cost);
        setFreight_value(freight_value);
    }

    public Order_items(int order_id,int order_item_id,String product_id,String seller_id,String shipping_limit_date,int product_price,int product_cost,int freight_value){
        setOrder_id(order_id);
        setOrder_item_id(order_item_id);
        setProduct_id(product_id);
        setSeller_id(seller_id);
        setShipping_limit_date(shipping_limit_date);
        setProduct_price(product_price);
        setProduct_cost(product_cost);
        setFreight_value(freight_value);
    }

    public String getProduct_id() {
        return product_id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public int getOrder_item_id() {
        return order_item_id;
    }

    public int getProduct_cost() {
        return product_cost;
    }

    public int getFreight_value() {
        return freight_value;
    }

    public String getSeller_id() {
        return seller_id;
    }

    public int getProduct_price() {
        return product_price;
    }

    public String getShipping_limit_date() {
        return shipping_limit_date;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public void setOrder_item_id(int order_item_id) {
        this.order_item_id = order_item_id;
    }

    public void setSeller_id(String seller_id) {
        this.seller_id = seller_id;
    }

    public void setFreight_value(int freight_value) {
        this.freight_value = freight_value;
    }

    public void setProduct_cost(int product_cost) {
        this.product_cost = product_cost;
    }

    public void setProduct_price(int product_price) {
        this.product_price = product_price;
    }

    public void setShipping_limit_date(String shipping_limit_date) {
        this.shipping_limit_date = shipping_limit_date;
    }

    @Override
    public String toString() {
        return "Order_items{" +
                "order_id=" + this.order_id +
                ", order_item_id=" + this.order_item_id +
                ", product_id='" + this.product_id + '\'' +
                ", seller_id='" + this.seller_id + '\'' +
                ", shipping_limit_date='" + this.shipping_limit_date + '\'' +
                ", product_price=" + this.product_price +
                ", product_cost=" + this.product_cost +
                ", freight_value=" + this.freight_value +
                '}';
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/CRM DB";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    Scanner scan = new Scanner(System.in);


    public void OrderItemLoop() {
        while (true) {
            System.out.println("Welcome to the Order-Item loop");
            System.out.println("Choose option:");
            System.out.println("[1] Show all data of table Order-Item ");
            System.out.println("[2] Profit of Company");

            Scanner input = new Scanner(System.in);
            int respond = input.nextInt();
            if (respond == 1) {

                System.out.println("V rdzrabotke");
            }
            if (respond == 2) {
                calculateProfitOfCompany();
            }

        }
    }

    public void calculateProfitOfCompany(){
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("select sum(product_price-product_cost) as total from Order_items");
            while (rs.next()) // Processing the result
                System.out.println(" " + rs.getInt("total" + "$")
                );
        }

        catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }

    }

}
