package com.company;

public class Main {

    public static void main(String[] args) {
        MyAppliccation app = new MyAppliccation();
        app.start();
    }
}
