package com.company;
import com.company.*;
import com.company.entities.*;


import java.util.Scanner;

public class MyAppliccation {
    Scanner scanner = new Scanner(System.in);
    Customer customer = new Customer();
    Product item = new Product();
    Orders tovar = new Orders();
    Order_items tovarD = new Order_items();
    CustomerInput customer2 = new CustomerInput();


    public void start() {
        System.out.println("Welcome to User application!");
        System.out.println("Choees your option:");
        System.out.println("[1] - Customer data analysis");
        System.out.println("[2] - Product data analysis");
        System.out.println("[3] - Order_items table");
        System.out.println("[4] - Order table");

        System.out.println("[5] - Input the data of customer");

        int respond = scanner.nextInt();
        do{
            if(respond == 1){
                customer.Customer_loop();
            }
            if(respond == 2){
                item.ItemLoop();
            }
            if(respond == 3){
                tovarD.OrderItemLoop();
            }
            if(respond == 4){

                tovar.OrderLoop();
            }
            if(respond == 5){
                customer2.InputData();
            }
        }while (false);
    }  //choose one of the  option
}
