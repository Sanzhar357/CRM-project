package com.company.entities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Orders {
    private int customer_ID;
    private String order_status;
    private String order_purchase_timestamp;
    private String order_approved_at;
    private String order_delivered_carrier_date;
    private String order_delivered_customer_date;
    private String order_estimated_delivery_date;

    public Orders() {

    }

    public Orders(int customer_ID, String order_status, String order_purchase_timestamp, String order_approved_at, String order_delivered_carrier_date, String order_delivered_customer_date, String order_estimated_delivery_date) {
        setCustomer_ID(customer_ID);
        setOrder_status(order_status);
        setOrder_purchase_timestamp(order_purchase_timestamp);
        setOrder_approved_at(order_approved_at);
        setOrder_delivered_carrier_date(order_delivered_carrier_date);
        setOrder_delivered_customer_date(order_delivered_customer_date);
        setOrder_estimated_delivery_date(order_estimated_delivery_date);
    }

    public int getCustomer_ID() {
        return customer_ID;
    }

    public void setCustomer_ID(int customer_ID) {
        this.customer_ID = customer_ID;
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public String getOrder_purchase_timestamp() {
        return order_purchase_timestamp;
    }

    public void setOrder_purchase_timestamp(String order_purchase_timestamp) {
        this.order_purchase_timestamp = order_purchase_timestamp;
    }

    public String getOrder_approved_at() {
        return order_approved_at;
    }

    public void setOrder_approved_at(String order_approved_at) {
        this.order_approved_at = order_approved_at;
    }

    public String getOrder_delivered_carrier_date() {
        return order_delivered_carrier_date;
    }

    public void setOrder_delivered_carrier_date(String order_delivered_carrier_date) {
        this.order_delivered_carrier_date = order_delivered_carrier_date;
    }

    public String getOrder_delivered_customer_date() {
        return order_delivered_customer_date;
    }

    public void setOrder_delivered_customer_date(String order_delivered_customer_date) {
        this.order_delivered_customer_date = order_delivered_customer_date;
    }

    public String getOrder_estimated_delivery_date() {
        return order_estimated_delivery_date;
    }

    public void setOrder_estimated_delivery_date(String order_estimated_delivery_date) {
        this.order_estimated_delivery_date = order_estimated_delivery_date;
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/CRM DB";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;
    Scanner scan = new Scanner(System.in);

    public void OrderLoop() {
        while (true) {
            System.out.println("Welcome to the Order-Item loop");
            System.out.println("Choose option:");

            System.out.println("[1] Show active customers");
            System.out.println("[2] Show order status of customers");

            Scanner input = new Scanner(System.in);
            int respond = input.nextInt();
            if (respond == 1) {
                findActiveCustomers();
            }

            if (respond == 2) {

                showOrderStatus();
            }

        }


    }


    public void findActiveCustomers() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("\n" +
                    "select Customer.customer_id,customer_Fname, customer_Lname, customer_email\n" +
                    "From Customer\n" +
                    "Left join Orders\n" +
                    "on Customer.customer_id=Orders.customer_id\n" +
                    "where order_purchase_timestamp >'2016-01-01'");

            System.out.println("The customers who have made an order for the last 5 years: ");
            while (rs.next()) // Processing the result
                System.out.println(rs.getInt("customer_id") + "       " +
                        rs.getString("customer_Fname") + "       " +
                        rs.getString("customer_Lname") + "       " +
                        rs.getString("customer_email"));

        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }
    }

    public void showOrderStatus() {
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("select Customer.customer_id,customer_Fname, customer_Lname, customer_email, order_status\n" +
                    "From Customer\n" +
                    "Left join Orders\n" +
                    "on Customer.customer_id=Orders.customer_id\n" +
                    "where order_status = 'invoiced'");

            System.out.println("Order status invoiced: ");
            while (rs.next()) // Processing the result
                System.out.println(+rs.getInt("customer_id") + "       " +
                        rs.getString("customer_Fname") + "       " +
                        rs.getString("customer_Lname") + "       " +
                        rs.getString("customer_email") + "       " +
                        rs.getString("order_status") + "       ");

            rs = stmt.executeQuery("select Customer.customer_id,customer_Fname, customer_Lname, customer_email, order_status\n" +
                    "From Customer\n" +
                    "Left join Orders\n" +
                    "on Customer.customer_id=Orders.customer_id\n" +
                    "where order_status = 'shipped'");

            System.out.println("Order status shipped: ");
            while (rs.next()) // Processing the result
                System.out.println(+rs.getInt("customer_id") + "       " +
                        rs.getString("customer_Fname") + "       " +
                        rs.getString("customer_Lname") + "       " +
                        rs.getString("customer_email") + "       " +
                        rs.getString("order_status") + "       ");

            rs = stmt.executeQuery("select Customer.customer_id,customer_Fname, customer_Lname, customer_email, order_status\n" +
                    "From Customer\n" +
                    "Left join Orders\n" +
                    "on Customer.customer_id=Orders.customer_id\n" +
                    "where order_status = 'delivered'");

            System.out.println("Order status delivered: ");
            while (rs.next()) // Processing the result
                System.out.println(+rs.getInt("customer_id") + "       " +
                        rs.getString("customer_Fname") + "       " +
                        rs.getString("customer_Lname") + "       " +
                        rs.getString("customer_email") + "       " +
                        rs.getString("order_status") + "       ");

        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }
    }

}

