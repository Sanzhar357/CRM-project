package com.company.controllers.interfaces;

import java.sql.DriverManager;
import java.util.Scanner;

public interface IProductController {
    public void ItemLoop();

    public void letterOfNameDescrip();

    public void massOfProduct();
}
