package com.company;

public class Main {
    public static void main(String[] args) {
        MyApplication app = new MyApplication();
        app.start();
    }
}
