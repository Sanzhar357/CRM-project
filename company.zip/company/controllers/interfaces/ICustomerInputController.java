package com.company.controllers.interfaces;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Calendar;
import java.util.Scanner;

public interface ICustomerInputController  {
    public void InputData();
}
