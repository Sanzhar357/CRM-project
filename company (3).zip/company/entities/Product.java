package com.company.entities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Product {


    private String product_id;
    private String product_category;
    private int product_name_length;
    private int product_description_length;
    private int product_photos_qty;
    private int product_weight_g;
    private int product_length_cm;
    private int product_geight_cm;
    private int product_width_cm;



    public Product()
    {
    }



    public Product(String product_id,String product_category,int product_name_length, int product_description_length, int product_photos_qty,
                   int product_weight_g,int product_length_cm,int product_geight_cm,int product_width_cm ){
        setProduct_id(product_id);
        setProduct_category(product_category);
        setProduct_name_length(product_name_length);
        setProduct_description_length(product_description_length);
        setProduct_photos_qty(product_photos_qty);
        setProduct_weight_g(product_weight_g);
        setProduct_length_cm(product_length_cm);
        setProduct_geight_cm(product_geight_cm);
        setProduct_width_cm(product_width_cm);
    }


    public int getProduct_description_length() {
        return product_description_length;
    }

    public int getProduct_geight_cm() {
        return product_geight_cm;
    }

    public int getProduct_length_cm() {
        return product_length_cm;
    }

    public int getProduct_name_length() {
        return product_name_length;
    }

    public String getProduct_id() {
        return product_id;
    }

    public int getProduct_photos_qty() {
        return product_photos_qty;
    }

    public String getProduct_category() {
        return product_category;
    }

    public int getProduct_weight_g() {
        return product_weight_g;
    }

    public int getProduct_width_cm() {
        return product_width_cm;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    public void setProduct_description_length(int product_description_length) {
        this.product_description_length = product_description_length;
    }

    public void setProduct_length_cm(int product_length_cm) {
        this.product_length_cm = product_length_cm;
    }

    public void setProduct_geight_cm(int product_geight_cm) {
        this.product_geight_cm = product_geight_cm;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public void setProduct_name_length(int product_name_length) {
        this.product_name_length = product_name_length;
    }

    public void setProduct_photos_qty(int product_photos_qty) {
        this.product_photos_qty = product_photos_qty;
    }

    public void setProduct_weight_g(int product_weight_g) {
        this.product_weight_g = product_weight_g;
    }

    public void setProduct_width_cm(int product_width_cm) {
        this.product_width_cm = product_width_cm;
    }

    @Override
    public String toString() {
        return "Product{" +
                "product_id='" + this.product_id + '\'' +
                ", product_category='" + this.product_category + '\'' +
                ", product_name_length=" + this.product_name_length +
                ", product_description_length=" + this.product_description_length +
                ", product_photos_qty=" + this.product_photos_qty +
                ", product_weight_g=" + this.product_weight_g +
                ", product_length_cm=" + this.product_length_cm +
                ", product_geight_cm=" + this.product_geight_cm +
                ", product_width_cm=" + this.product_width_cm +
                '}';
    }

    public void ItemLoop(){
        while (true){
            System.out.println("Welcome to the Product-loop");
            System.out.println("Choose option:");
            System.out.println("[1] - heavy five products to transport");
            System.out.println("[2] Product: Name-length, Description-length");


            Scanner input = new Scanner(System.in);
            int respond = input.nextInt();

            if(respond == 1){

                massOfProduct();

            }
            if(respond == 2){
                letterOfNameDescrip();
            }

        }
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/CRM DB";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;

    public void letterOfNameDescrip(){
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("select * from Products");
            while (rs.next()) // Processing the result
                System.out.println(" " + rs.getInt("product_id") + "      "
                        + rs.getInt("product_name_length") + " letter      "
                        + rs.getInt("product_description_length") + " letter      "
                );
        }

        catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }


    }

    public void massOfProduct(){
        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("select product_id, product_weight_g\n" +
                    "from Products\n" +
                    "order by product_weight_g desc\n" +
                    "limit 5 ");

            System.out.println("The heaviest 5 products: ");
            System.out.println("product_id     mass(g)");
            while (rs.next()) // Processing the result
                System.out.println( rs.getInt("product_id")+ "       " + rs.getInt("product_weight_g"));



        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }

    }
}
