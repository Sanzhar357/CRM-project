package com.company.entities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;
import java.sql.ResultSet;
import java.sql.Statement;

public class Customer {

    protected int customer_ID;
    protected String customer_fName;
    protected String customer_lName;
    protected String customer_dateB;
    protected String customer_gender;
    protected String customer_phoneN;
    protected  String customer_email;
    protected  String customer_city;
    protected  String customer_state;
    protected  String customer_occupancy;
    protected  int customer_aFunds;


    public Customer() {

    }

    public Customer(String customer_fName, String customer_lName, String customer_dateB, String customer_gender, String customer_phoneN, String customer_email, String customer_city, String customer_state, String customer_occupancy) {
        setCustomer_fName(customer_fName);
        setCustomer_lName(customer_lName);
        setCustomer_dateB(customer_dateB);
        setCustomer_gender(customer_gender);
        setCustomer_phoneN(customer_phoneN);
        setCustomer_email(customer_email);
        setCustomer_city(customer_city);
        setCustomer_state(customer_state);
        setCustomer_occupancy(customer_occupancy);

    }

    public Customer(int customer_ID, String customer_fName, String customer_lName, String customer_dateB, String customer_gender, String customer_phoneN, String customer_email, String customer_city, String customer_state, String customer_occupancy, int customer_aFunds) {
        setCustomer_ID(customer_ID);
        setCustomer_fName(customer_fName);
        setCustomer_lName(customer_lName);
        setCustomer_dateB(customer_dateB);
        setCustomer_gender(customer_gender);
        setCustomer_phoneN(customer_phoneN);
        setCustomer_email(customer_email);
        setCustomer_city(customer_city);
        setCustomer_state(customer_state);
        setCustomer_occupancy(customer_occupancy);
        setCustomer_aFunds(customer_aFunds);
    }

    public int getCustomer_ID() {
        return customer_ID;
    }

    public void setCustomer_ID(int customer_ID) {
        this.customer_ID = customer_ID;
    }

    public String getCustomer_fName() {
        return customer_fName;
    }

    public void setCustomer_fName(String customer_fName) {
        this.customer_fName = customer_fName;
    }

    public String getCustomer_lName() {
        return customer_lName;
    }

    public void setCustomer_lName(String customer_lName) {
        this.customer_lName = customer_lName;
    }

    public String getCustomer_dateB() {
        return customer_dateB;
    }

    public void setCustomer_dateB(String customer_dateB) {
        this.customer_dateB = customer_dateB;
    }

    public String getCustomer_gender() {
        return customer_gender;
    }

    public void setCustomer_gender(String customer_gender) {
        this.customer_gender = customer_gender;
    }

    public String getCustomer_phoneN() {
        return customer_phoneN;
    }

    public void setCustomer_phoneN(String customer_phoneN) {
        this.customer_phoneN = customer_phoneN;
    }

    public String getCustomer_email() {
        return customer_email;
    }

    public void setCustomer_email(String customer_email) {
        this.customer_email = customer_email;
    }

    public String getCustomer_city() {
        return customer_city;
    }

    public void setCustomer_city(String customer_city) {
        this.customer_city = customer_city;
    }

    public String getCustomer_state() {
        return customer_state;
    }

    public void setCustomer_state(String customer_state) {
        this.customer_state = customer_state;
    }

    public String getCustomer_occupancy() {
        return customer_occupancy;
    }

    public void setCustomer_occupancy(String customer_occupancy) {
        this.customer_occupancy = customer_occupancy;
    }

    public double getCustomer_aFunds() {
        return customer_aFunds;
    }

    public void setCustomer_aFunds(int customer_aFunds) {
        this.customer_aFunds = customer_aFunds;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customer_ID = " + this.customer_ID +
                ", customer_fName = '" + this.customer_fName + '\'' +
                ", customer_lName = '" + this.customer_lName + '\'' +
                ", customer_dateB = '" + this.customer_dateB + '\'' +
                ", customer_gender=" + this.customer_gender +
                ", customer_phoneN = '" + this.customer_phoneN + '\'' +
                ", customer_email = '" + this.customer_email + '\'' +
                ", customer_city = '" + this.customer_city + '\'' +
                ", customer_state = '" + this.customer_state + '\'' +
                ", customer_occupancy = '" + this.customer_occupancy + '\'' +
                ", customer_aFunds = '" + this.customer_aFunds +
                '}';
    }


    public void Customer_loop() {
        while (true) {
            System.out.println("Welcome to the user console!");
            System.out.println("Choose option:");
            System.out.println("[1] Show all data of table Customer ");
            System.out.println("[2] Age group data of table Customer");
            System.out.println("[3] Information of customer's geolocation");
            System.out.println("[4] Information about occupancy");

            Scanner input = new Scanner(System.in);
            int respond = input.nextInt();

            if (respond == 1) {
                showAllDataCustomer();
            }

            if (respond == 2) {
                selectTopAgeGroup();
            }

            if (respond == 3) {
                Geolocation();

            }
            if(respond == 4){

                determineOccupancy();
            }
        }
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/CRM DB";
    Connection con = null;
    ResultSet rs = null;
    Statement stmt = null;

    public void showAllDataCustomer() {

        try {

            // Here we load the driver’s class file into memory at the runtime
            Class.forName("org.postgresql.Driver");

            // Establish the connection
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery(" select  customer_ID ,customer_Fname, customer_Lname, customer_phoneN, customer_city, customer_dateB,customer_gender from Customer order by customer_id ");
            System.out.println("customer_ID     customer_Fname          customer_Lname      customer_phoneN      customer_city      customer_dateB     customer_gender");
            while (rs.next()) // Processing the result
                System.out.println(rs.getInt("customer_id") + "                  "
                        + rs.getString("customer_Fname") + "          " +
                        rs.getString("customer_Lname") + "          " +
                        rs.getString("customer_phoneN") + "          " +
                        rs.getString("customer_city") + "           " +
                        rs.getString("customer_dateB") + "          " +
                        rs.getString("customer_gender") + "           "
                );
            //rs.getString("empl_date_of_birth")
        } catch (Exception e) {
            System.out.println("Exception occurred!");

            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }

        System.out.println("Finished!");
    }


    public void selectTopAgeGroup() {


        try {

            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("SELECT count(DISTINCT customer_state) \n" +
                    "FROM Customer\n" +
                    "WHERE customer_dateB > '1991-01-01' and customer_dateB <= '2003-01-01';");


            while (rs.next()) // Processing the result
                System.out.println("The number of clients aged 18 to 30: " + rs.getInt("count")
                );


            rs = stmt.executeQuery("SELECT count(DISTINCT customer_state) \n" +
                    "FROM Customer\n" +
                    "WHERE customer_dateb > '1976-01-01' and customer_dateb <= '1991-01-01';");

            while (rs.next()) // Processing the result
                System.out.println("The number of clients aged 31 to 45: " + rs.getInt("count")
                );


            rs = stmt.executeQuery("SELECT count(DISTINCT customer_state) \n" +
                    "FROM Customer\n" +
                    "WHERE customer_dateb > '1961-01-01' and customer_dateb <= '1976-01-01';");

            while (rs.next()) // Processing the result
                System.out.println("The number of clients aged 46 to 60: " + rs.getInt("count")
                );


            rs = stmt.executeQuery("SELECT count(DISTINCT customer_state) \n" +
                    "FROM Customer\n" +
                    "WHERE  customer_dateb <= '1961-01-01';");


            while (rs.next()) // Processing the result
                System.out.println("The number of clients who are over 60 years old: " + rs.getInt("count")
                );


        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }


        System.out.println("Finished!\n\n");

    }

    public void Geolocation() {

        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("SELECT count(DISTINCT customer_state) \n" +
                    "FROM Customer\n");
            while (rs.next()) // Processing the result
                System.out.println("The number of States: " + rs.getInt("count")
                );
//-----------------------------------------------

            System.out.println("The top 5 state");
            rs = stmt.executeQuery("SELECT customer_state, COUNT(*) \n" +
                    "FROM Customer \n" +
                    "GROUP BY customer_state\n" +
                    "order by count desc\n" +
                    "limit 5");
            System.out.println("State           Qty");
            while (rs.next()) // Processing the result
                System.out.println(rs.getString("customer_state") + "         "+ rs.getInt("count")
                );

        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }


    }

    public void determineOccupancy(){

        try {
            Class.forName("org.postgresql.Driver");
            con = DriverManager.getConnection(connectionUrl, "postgres", "abcde");
            stmt = con.createStatement();

            rs = stmt.executeQuery("select count(*) from Customer\n" +
                    "where customer_occupancy = 'student'");
            while (rs.next()) // Processing the result
                System.out.println("The number of student: " + rs.getInt("count")
                );


            rs = stmt.executeQuery("select count(*) from Customer\n" +
                    "where customer_occupancy = 'worker'");
            while (rs.next()) // Processing the result
                System.out.println("The number of worker: " + rs.getInt("count")
                );

            rs = stmt.executeQuery("select count(*) from Customer\n" +
                    "where customer_occupancy = 'retired'");
            while (rs.next()) // Processing the result
                System.out.println("The number of pensioners: " + rs.getInt("count")
                );

            rs = stmt.executeQuery("select count(*) from Customer\n" +
                    "where customer_occupancy = 'unemployed'");
            while (rs.next()) // Processing the result
                System.out.println("The number of unemployed people: " + rs.getInt("count")
                );


        } catch (Exception e) {
            System.out.println("Exception occurred!");
            e.printStackTrace();
        } finally {

            try { // Close connection - clean up the system resources
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
                System.out.println("Exception occurred!");
            }
        }


    }
}
